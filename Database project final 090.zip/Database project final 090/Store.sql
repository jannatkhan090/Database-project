--customer
create table customer
(
    user_name varchar2(20) primary key,
    pswd varchar2(20) not null,
    phone_no number(10) not null,
    first_name varchar2(20) not null,
    last_name varchar2(20)
);
--address
create table address
(
    door_no varchar2(20),
    street varchar2(20) not null,
    landmark varchar2(50),
    city varchar2(20) not null,
    pincode number,
    user_name varchar2(20),
    primary key (door_no,pincode,user_name),
    foreign key (user_name) references customer(user_name)
);
--cards
create table cards
(
    card_no number(16),
    name_on_card varchar2(20) not null,
    cvv number(3) not null,
    expiry_date varchar2(10) not null,
    user_name varchar2(20),
    primary key (user_name,card_no),
    foreign key (user_name) references customer(user_name)
);
--product
create table product
(
    product_id number primary key,
    product_name varchar2(20) not null,
    mrp number not null,
    sale_price number not null,
    category_ varchar2(20)
);
--cart
create table cart
(
    product_id number,
    user_name varchar2(20),
    quantity number not null,
    primary key (product_id,user_name),
    foreign key (product_id) references product(product_id),
    foreign key (user_name) references customer(user_name)
);
--store_house
create table store_house
(
    sh_no number primary key,
    pincode number
);
--stock
create table stock
(
    product_id number,
    sh_no number,
    exp_date varchar2(10) not null,
    quantity number,
    primary key (product_id,sh_no),
    foreign key (product_id) references product,
    foreign key 
(sh_no) references store_house(sh_no)
);

--delivery_service
create table delivery_service
(
    ds_id number primary key,
    ds_name varchar2(20) not null,
    ds_phone_no number not null
);
--order
create table order_
(
    order_id number primary key,
    status varchar2(10) not null,
    total_price number not null,
    gross_price number not null,
    discount number not null,
    ds_id number not null,
    user_name varchar2(20) not null,
    foreign key (ds_id) references delivery_service(ds_id),
    foreign key (user_name) references customer(user_name)
);
--ordered_item
create table ordered_item
(
    order_id number,
    product_id number,
    quanity number not null,
    primary key (order_id,product_id),
    foreign key (order_id) references order_(order_id),
    foreign key (product_id) references product(product_id)
);
--payment
create table payment
(
    tran_id number primary key,
    amount number not null,
    card_no number(16) not null,
    order_id number,
    foreign key (order_id) references order_(order_id)
);
--INSERTION OF DATA INTO TABLES:
insert into customer
values('venu123', '1234@45', 9894983923, 'venu', 'gopal');
insert into customer
values('trk234', '7822A@45', 9387388222, 'tene', 'ramakrishnudu');
insert into customer
values('kr189', '723@4A5', 6478240103, 'kota', 'ramesh');
insert into customer
values('pvsr1589', '899&45', 6304998763, 'venkat', 'subbareddy');
insert into customer
values('balu345', 'balu&45', 7837832230, 'raja', 'balu');
insert into customer
values('vikas11', 'villu189', 6984720334, 'vikas', 'kumar');
insert into customer
values('Sarath2193', 'dsc@2193', 9392588083, 'Sarath', 'Chandra');
insert into customer
values('Priya6606', 'dvp@0606', 8301603505, 'Visnu', 'Priya');
insert into customer
values('Venky1123', 'pvk@123', 9989608441, 'Venkatesh', null);
insert into customer
values('Saketh1456', 'msd@666', 7702774158, 'Saketh', 'kumar');
insert into customer
values('Reshma1234', 'resh@789', 745896321, 'Reshma', 'Lakshmi');
insert into address
values('1/1189/17/4', 'ngo colony', 'near temple', 'kadiri', 515591, 'venu123');
insert into address
values('112-783-9', 'rgo colony', 'near fs', 'hyderabad', 513501, 'trk234');
insert into address
values('7673-847', 'revenue colony', 'above sbi', 'ongole', 517876, 'venu123');
insert into address
values('159/12', 'raj nagar', 'near hdfc', 'ongole', 517876, 'vikas11');
insert into address
values('27/45/111', 'ngo colony', 'plsql', 'warangal', 514442, 'kr189');
insert into 
address
values('18/189/15', 'tea nagar', 'autonagar', 'kazipet', 537591, 'kr189');
insert into address
values('199/13/4', 'gandhi street', 'near temple', 'hyderabad', 513501, 'trk234');
insert into address
values('19/17/22', 'nehru colony', 'cofee store', 'kazipet', 537591, 'balu345');
insert into address
values('15/01/2003', 'chowk', 'street kart', 'warangal', 514442, 'pvsr1589');
insert into address
values('6-102/A', 'Aravinda Nagar', 'near chaitanya', 'Rajahmundry', 533107, 'Sarath2193');
insert into address
values('6-380', 'Sai Nagar', 'near sbi', 'kakinda', 520143, 'Priya6606');
insert into address
values('3/11/180', 'kanchumurthi street', null, 'Vizag', 500108, 'Venky1123');
insert into address
values('8-150/B', 'Venkatesh Nagar', 'near hospital', 'Nellore', 510269, 'Saketh1456');
insert into address
values('7-863-2', 'Ganesh Nagar', 'near 
police', 'Hyderabad', 521486, 'Reshma1234');
insert into address
values('4-7-33', 'Priya 
Nagar', null, 'Warangal', 500107, 'Sarath2193');
insert into address
values('5-786/C', 'Mallesh Nagar', 'near cyclestand', 'Chennai', 513602, 'Priya6606');
insert into 
address
values('2-98-36/B', 'Harsha Nagar', null, 'Tirupathi', 542148, 'Venky1123');
insert into cards
values(2389162526617634, 'venu gopal', 745, '2/2025', 'venu123');
insert into cards
values(1889162526617634, 'rama krishna', 145, '7/2026', 'trk234');
insert into cards
values(1789162526617634, 'rama 
krishna', 785, '3/2025', 'trk234');
insert into cards
values(1781625266176343, 'vikas raj', 749, '11/2024', 'vikas11');
insert into cards
values(2429162526617634, 'vikas raj', 655, '4/2025', 'vikas11');
insert into cards
values(2399912526617634, 'pv reddy', 148, '2/2026', 'pvsr1589');
insert into cards
values(9889162526617634, 'bala krishna', 245, '2/2024', 'balu345');
insert into cards
values(1589162526617634, 'kota ramesh', 395, '11/2024', 'kr189');
insert into cards
values(2569162526617634, 'kota ramesh', 985, '2/2027', 'kr189');
insert into cards
values(5596010065137004, 'Sarath Chandra', 773, '4/2022', 'Sarath2193');
insert into cards
values(7896412536894125, 'Vishnu Priya', 758, '6/2023', 'Priya6606');
insert into cards
values(7456893214536982, 'Venkatesh', 123, '8/2024', 'Venky1123');
insert into cards
values(4568123698412536, 'Saketh', 769, '7/2026', 'Saketh1456');
insert into cards
values(1456236589457412, 'Reshma', 854, '4/2023', 'Reshma1234');
insert into cards
values(4789564123459874, 'Sarath Chandra', 456, '9/2024', 'Sarath2193');
insert into cards
values(7896541236547892, 'Vishnu 
Priya', 665, '4/2025', 'Priya6606');
insert into cards
values(1456247898412365, 'Reshma', 123, '5/2026', 'Reshma1234');
insert into product
values(123, 'powder', 250, 230, 'cosmetics');
insert into product
values(289, 'oil', 270, 210, 'cosmetics');
insert into product
values(323, 'comb', 60, 60, 'cosmetics');
insert into product
values(472, 'brush', 30, 25, null);
insert into product
values(517, 'soap', 70, 60, 'detergents');
insert into product
values(571, 'harpic', 170, 130, 'detergents');
insert into product
values(593, 'lizol', 210, 190, 'detergent');
insert into product
values(621, 'earphones', 1250, 1155, 'electronics');
insert into product
values(712, 'Trimmer', 1400, 1270, 'electronics');
insert into product
values(836, 'masks', 500, 470, null);
insert into product
values(850, 'Watch', 1500, 1350, 'Gadgets');
insert into product
values(942, 'speaker', 1780, 1500, 'electronics');

insert into cart
values(289, 'venu123', 4);
insert into cart
values(712, 'vikas11', 3);
insert into cart
values(517, 'trk234', 4);
insert into cart
values(517, 'kr189', 6);
insert into cart
values(323, 'pvsr1589', 3);
insert into cart
values(472, 'trk234', 2);
insert into cart
values(621, 'balu345', 5);
insert into cart
values(289, 'balu345', 2);
insert into cart
values(123, 'vikas11', 6);
insert into cart
values(850, 'Sarath2193', 1);
insert into cart
values(517, 'Priya6606', 5);
insert into cart
values(472, 'Venky1123', 2);
insert into cart
values(123, 'Saketh1456', 3);
insert into cart
values(621, 'Reshma1234', 2);
insert into cart
values(571, 'Venky1123', 3);
insert into cart
values(836, 'Sarath2193', 6);
insert into cart
values(942, 'Priya6606', 2);
insert into cart
values(593, 'Saketh1456', 3);
insert into store_house
values(118, 515562);
insert into store_house
values(237, 532893);
insert into store_house
values(158, 571881);
insert into store_house
values(173, 532893);
insert into store_house
values(199, 571881);
insert into store_house
values(129, 532893);
insert into stock
values(123, 118, '15/03/23', 50);
insert into stock
values(123, 237, '17/03/24', 65);
insert into stock
values(472, 199, '02/07/23', 40);
insert into stock
values(289, 158, '15/03/23', 70);
insert into stock
values(323, 129, '15/12/23', 20);
insert into stock
values(593, 129, '18/04/25', 120);
insert into stock
values(517, 118, '9/06/24', 80);
insert into stock
values(517, 237, '11/07/24', 70);
insert into stock
values(593, 199, '13/11/24', 110);
insert into stock
values(621, 237, '24/04/2024', 75);
insert into stock
values(712, 158, '28/06/2023', 85);
insert into stock
values(836, 118, '21/09/2024', 79);
insert into stock
values(850, 173, '07/09/2025', 100);
insert into stock
values(942, 199, '23/07/2024', 80);
insert into stock
values(712, 129, '17/05/2022', 64);
insert into stock
values(850, 118, '15/06/2025', 45);
insert into delivery_service
values(665, 'bluedart', 97809824827);
insert into delivery_service
values(765, 'ekart', 8976524321);
insert into delivery_service
values(865, 'electo_smart', 87809824827);
insert into delivery_service
values(965, 'weeter', 69909824827);
insert into delivery_service
values(365, 'rheels_kart', 89309824827);

insert into order_
values(100, 'paid', 1700, 1650, 90, 865, 'venu123');
insert into order_
values(101, 'paid', 1100, 1050, 95, 365, 'trk234');
insert into order_
values(102, 'paid', 1900, 1850, 70, 765, 'balu345');
insert into order_
values(103, 'paid', 1470, 1340, 75, 365, 'Sarath2193');
insert into order_
values(104, 'paid', 1520, 1300, 120, 765, 'Priya6606');
insert into order_
values(105, 'paid', 1745, 1625, 150, 865, 'Venky1123');
insert into ordered_item
values(100, 289, 4);
insert into ordered_item
values(101, 517, 4);
insert into ordered_item
values(101, 472, 2);
insert into ordered_item
values(102, 289, 2);
insert into ordered_item
values(102, 621, 5);
insert into ordered_item
values(103, 836, 6);
insert into ordered_item
values(104, 517, 5);
insert into ordered_item
values(105, 472, 2);
insert into ordered_item
values(103, 850, 1);
insert into ordered_item
values(104, 942, 2);
insert into ordered_item
values(105, 571, 3);
insert into payment
values(12345, 1700, 2389162526617634, 100);
insert into payment
values(12346, 1100, 1789162526617634, 101);
insert into payment
values(12347, 1900, 9889162526617634, 102);
insert into payment
values(12348, 1470, 4789564123459874, 103);
insert into payment
values(12349, 1520, 7896541236547892, 104);
insert into payment
values(12350, 1745, 7456893214536982, 105); 
